When you meet a bug, please open the issue including a title prefixed by '[bug]' and describe it as follows:

### Expected behavior

### Actual behavior

### Steps to reproduce the behavior 
